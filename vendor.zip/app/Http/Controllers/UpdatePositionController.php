<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UpdatePositionController extends Controller
{
    //
}
